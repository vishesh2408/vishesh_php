<?php

$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Session.php');
Session::init();

include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');
spl_autoload_register(function($class){
	include_once "classes/".$class.".php";
});

$db   = new Database();
$fm   = new Format();
$exam = new Exam();
$user = new User();
$pro  = new Process();

header("Cache-Control: no-store, no-cache, must-revalidate"); 
header("Cache-Control: pre-check=0, post-check=0, max-age=0"); 
header("Pragma: no-cache"); 
header("Expires: Mon, 6 Dec 1977 00:00:00 GMT"); 
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
?>
<?php
  if (isset($_GET['action']) && $_GET['action'] == 'logout') {
  	     Session::destroy();
  	     header("Location:index.php");
  	     exit();
  }
?>
<!doctype html>
<html>
<head>
	<title>Online Exam System</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
    <link rel="stylesheet" href="css/footer.css">
   


<!-- Navigation -->

        <style>
            /* Navbar Styles */

.navbar {
  background-color: #333;
  padding: 10px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-family: 'Verdana', sans-serif; /* Apply Verdana font */
}

.navbar .navbar-brand {
  color: #fff;
  text-decoration: none;
  font-size: 1.5em;
}

.navbar .navbar-toggler {
  display: none;
  background-color: transparent;
  border: none;
  font-size: 1.5em;
  color: #fff;
  cursor: pointer;
}

.navbar .navbar-toggler-icon {
  font-size: 1.5em;
}

.navbar-links {
  display: flex;
  justify-content: flex-end; /* Align the entire list to the right */
  width: 100%;
}

.navbar-nav {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: flex-end; /* Align all items inside the ul to the right */
  width: 100%; /* Make sure it takes up the full width */
}

.nav-item {
  margin-left: 20px;
}

.nav-link {
  color: #fff;
  text-decoration: none;
  font-size: 1em;
  padding: 5px 10px;
}

.nav-link:hover {
  background-color: #555;
  border-radius: 5px;
}

.active .nav-link {
  font-weight: bold;
}

@media (max-width: 768px) {
  .navbar .navbar-toggler {
    display: block;
  }
  
  .navbar-links {
    display: none;
    width: 100%;
    position: absolute;
    top: 40px;
    left: 0;
    background-color: #333;
    padding: 10px;
    box-sizing: border-box;
  }

  .navbar-links.active {
    display: block;
  }

  .navbar-nav {
    flex-direction: column;
    align-items: center;
  }

  .nav-item {
    margin: 10px 0;
  }
}



        </style>
    </head>
  <body>
  <nav class="navbar">
  <div class="container">
    <a class="navbar-brand" href="#" style="margin-top:50px">Online Examination System</a>
    <button class="navbar-toggler" id="navbarToggler" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon">&#9776;</span>
    </button>
    <div class="navbar-links" id="navbarLinks" style="margin-left:250px;margin-bottom:10px;">
      <ul class="navbar-nav">
        <?php
          $login = Session::get("login");
          if ($login == true) {
        ?>
        <li class="nav-item active">
          <a class="nav-link" href="#">Welcome <strong><?php echo Session::get("name"); ?></strong></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="profile.php">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="exam.php">Exam</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="?action=logout">Logout</a>
        </li>
        <?php } else { ?>
        <li class="nav-item"><a class="nav-link" href="index.php">Login</a></li>
        <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
        <li class="nav-item"><a class="nav-link" href="admin/">Admin</a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
</nav>

