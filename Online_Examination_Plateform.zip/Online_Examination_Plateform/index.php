<?php include 'inc/header.php'; ?>
<?php
  Session::checkLogin();
?>





<div class="container">
    <div class="text-center">
        <h1>Online Examination System</h1>
        <p class="lead">Simple MCQ Based Online Examination System!</p>
        <img src="img/bgtest.png" alt="Logo"/>
    </div>

    <div class="form-section">
        <form id="loginForm" action="index.php" method="post"> 
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Password">
            </div>
            <button type="submit" id="loginsubm" value="Signup" class="btn">Log In</button>
        </form>
        <br/>
        <p><a class="btn btn-outline-info" href="register.php">New User? Signup for Free</a></p>
        <span class="empty">Fields must not be empty</span>
        <span class="disable">User ID Disable!</span>
        <span class="error">Email or Password did not match.</span>
    </div>
</div>

<script>
    // Form validation on submit
    document.getElementById('loginForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting

        // Get form values
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        const emptyMessage = document.querySelector('.empty');
        const errorMessage = document.querySelector('.error');
        const disableMessage = document.querySelector('.disable');

        // Reset error messages
        emptyMessage.style.display = 'none';
        errorMessage.style.display = 'none';
        disableMessage.style.display = 'none';

        // Validate fields
        if (email === '' || password === '') {
            emptyMessage.style.display = 'inline-block';
        } else if (email === 'disabled@example.com') { // Example for user ID disable
            disableMessage.style.display = 'inline-block';
        } else {
            // Simulate email and password validation (you can replace this with server-side validation)
            if (email === 'test@example.com' && password === 'password123') {
                // Proceed with form submission (uncomment next line to allow submission)
                // this.submit();
                alert("Logged in successfully!");
            } else {
                errorMessage.style.display = 'inline-block';
            }
        }
    });
</script>
      
	   
<?php include 'inc/footer.php'; ?>