</body>

<!-- Footer -->
<!-- Header -->


<!-- Footer -->
<section id="footer" style="height:60%">
  <div class="container">
    <div class="row">
      <!-- About Section -->
      <div class="footer-column col-md-3">
        <h5>About</h5>
        <p style="color:white">Top learning experiences that create more talent in the world.</p>
      </div>
      
      <!-- Quick Links Sections -->
      <div class="footer-column col-md-2">
        <h5>Quick links</h5>
        <ul class="quick-links">
          <li><a href="#">Overview</a></li>
          <li><a href="#">Features</a></li>
          <li><a href="#">Solutions</a></li>
         
        </ul>
      </div>
      
      <div class="footer-column col-md-2">
        <h5>Company</h5>
        <ul class="quick-links">
          <li><a href="#">About us</a></li>
          <li><a href="#">Career</a></li>
          <li><a href="#">News</a></li>
         
        </ul>
      </div>

      <div class="footer-column col-md-2">
        <h5>Social</h5>
        <ul class="quick-links">
          <li><a href="#">Linkedin</a></li>
          <li><a href="#">Unstop</a></li>
          <li><a href="#">GitHub</a></li>
         
        </ul>
      </div>
      
      <div class="footer-column col-md-2">
        <h5>Legal</h5>
        <ul class="quick-links">
          <li><a href="#">Privacy</a></li>
          <li><a href="#">Cookie</a></li>
          <li><a href="#">Contact</a></li>
         
        </ul>
      </div>
      
      <!-- Other Links Sections -->
      <!-- Repeat similar structure as per your needs for "Company", "Social", and "Legal" -->

    </div>

	<div class="social-container" style="position: absolute; bottom: -850px; right: 70px; color:white;">
    <ul class="social" style="list-style: none; display: flex; gap: 10px; padding: 0; margin: 0;">
        <li style="display: inline;"><a href="#" style="text-decoration: none; color: inherit;"><i class="fa fa-instagram"></i></a></li>
        <li style="display: inline;"><a href="#" style="text-decoration: none; color: inherit;"><i class="fa fa-linkedin"></i></a></li>
        <li style="display: inline;"><a href="#" style="text-decoration: none; color: inherit;"><i class="fa fa-github"></i></a></li>
    </ul>
</div>



    <!-- Footer Bottom -->
    <div class="footer-bottom">
      <p style="color:white">&copy; 2022 Ed-Circle. All rights reserved.</p>
    </div>
  </div>
</section>


  <!-- ./Footer -->
  <script>
  $(document).ready(function() {
    // Example: Hover effect for social media icons
    $(".social a").hover(function() {
        $(this).css("color", "#00aaff");
    }, function() {
        $(this).css("color", "#fff");
    });

    // Example: Smooth scroll for quick links
    $(".quick-links a").click(function(e) {
        e.preventDefault();
        alert('This is a placeholder link.');
    });
});




<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</footer>